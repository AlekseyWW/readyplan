<?php echo e($slot); ?>

<?php /**PATH /Users/aleksejvaznikov/dev/websites/laravels/ready-plan.ru/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>
<div class="row">
    <div class="col-md-4">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">Настройки сайта</h3>
            </div>
            <div class="panel-body" style="padding-top: 20px;">
                <h3>
                    <img style="max-width: 200px" src="/storage/<?php echo e(setting('site.logo')); ?>" alt="">
                </h3>
                <h3><small>Название:</small><br><b><?php echo e(setting('site.title')); ?></b></h3>
                <p><small>Описание:</small><br><b><?php echo e(setting('site.description')); ?><b></p>
                <p><small>Телефон:</small><br><b><?php echo e(setting('site.phone')); ?><b></p>
                <p><small>Почта:</small><br><b><?php echo e(setting('site.email')); ?><b></p>
            </div>
            <div class="panel-footer clearfix">
                <a href="<?php echo e(route('voyager.settings.index')); ?>" class="btn btn-primary btn-lg">Изменить</a>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="list-group">
                <div class="list-group-item d-flex justify-content-between align-items-center">
                        
                    <span class="d-flex">
                        <?php if(isset($data->children[0])): ?>
                            <button style="margin-right: 8px" class="btn btn-sm btn-default" type="button" data-toggle="collapse" data-target="#collapse-<?php echo e($data->id); ?>" aria-expanded="false" aria-controls="collapse-<?php echo e($data->id); ?>">
                                <i class="voyager-angle-down"></i>
                            </button>
                        <?php else: ?>
                            <span style="width: 52px;"></span>
                        <?php endif; ?>
                        <h4><?php echo $data->title; ?></h4>
                    </span>
                    <div style="min-width: 184px;">
                        
                        <a href="<?php echo e(route('voyager.blocks.create', [ 'parent_id' => $data->id])); ?>" class="btn btn-sm btn-success pull-right view add">
                            <i class="voyager-plus"></i>
                        </a>
                        <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!method_exists($action, 'massAction')): ?>
                                <?php echo $__env->make('voyager::bread.partials.actions', ['action' => $action], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                </div>
                <ul class="list-group collapse" id="collapse-<?php echo e($data->id); ?>">
                    <?php if($data->children): ?>
                        <?php $__currentLoopData = $data->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <span><?php echo $item->title; ?></span>
                                <div>
                                    <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(!method_exists($action, 'massAction')): ?>
                                            <?php echo $__env->make('voyager::bread.partials.actions', ['action' => $action, 'data' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <ul>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>


<div class="modal modal-danger fade" tabindex="-1" id="delete_modal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo e(__('voyager::generic.close')); ?>"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><i class="voyager-trash"></i> <?php echo e(__('voyager::generic.delete_question')); ?> <?php echo e(strtolower($dataType->getTranslatedAttribute('display_name_singular'))); ?>?</h4>
            </div>
            <div class="modal-footer">
                <form action="#" id="delete_form" method="POST">
                    <?php echo e(method_field('DELETE')); ?>

                    <?php echo e(csrf_field()); ?>

                    <input type="submit" class="btn btn-danger pull-right delete-confirm" value="<?php echo e(__('voyager::generic.delete_confirm')); ?>">
                </form>
                <button type="button" class="btn btn-default pull-right" data-dismiss="modal"><?php echo e(__('voyager::generic.cancel')); ?></button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<?php $__env->startSection('javascript'); ?>
    <!-- DataTables -->
    <?php if(!$dataType->server_side && config('dashboard.data_tables.responsive')): ?>
        <script src="<?php echo e(voyager_asset('lib/js/dataTables.responsive.min.js')); ?>"></script>
    <?php endif; ?>
    <script>
        $(document).ready(function () {

            $('.select_all').on('click', function(e) {
                $('input[name="row_id"]').prop('checked', $(this).prop('checked')).trigger('change');
            });
        });


        var deleteFormAction;
        $('li').on('click', '.delete', function (e) {
            $('#delete_form')[0].action = '<?php echo e(route('voyager.'.$dataType->slug.'.destroy', '__id')); ?>'.replace('__id', $(this).data('id'));
            $('#delete_modal').modal('show');
        });

        $('input[name="row_id"]').on('change', function () {
            var ids = [];
            $('input[name="row_id"]').each(function() {
                if ($(this).is(':checked')) {
                    ids.push($(this).val());
                }
            });
            $('.selected_ids').val(ids);
        });
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH /Users/aleksejvaznikov/dev/websites/laravels/ready-plan.ru/resources/views/vendor/voyager/dimmer.blade.php ENDPATH**/ ?>
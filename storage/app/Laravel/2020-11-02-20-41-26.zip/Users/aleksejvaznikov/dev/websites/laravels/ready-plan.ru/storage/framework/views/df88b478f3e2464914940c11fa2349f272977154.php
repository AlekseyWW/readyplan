Новый контакт: <?php echo e($name); ?>


<h2><?php echo e($subject); ?></h2>
<?php if(isset($name)): ?>
    <p> Имя: <?php echo e($name); ?> </p>
<?php endif; ?>
<?php if(isset($email)): ?>
    <p> Email: <?php echo e($email); ?> </p>
<?php endif; ?>
<?php if(isset($phone)): ?>
    <p> Телефон: <?php echo e($phone); ?> </p>
<?php endif; ?>
<?php if(isset($position)): ?>
    <p> Должность: <?php echo e($position); ?> </p>
<?php endif; ?>
<?php if(isset($company)): ?>
    <p> Компания: <?php echo e($company); ?> </p>
<?php endif; ?>
<?php if(isset($bodyMessage)): ?>
    <p> Message: <?php echo e($bodyMessage); ?> </p>
<?php endif; ?><?php /**PATH /Users/aleksejvaznikov/dev/websites/laravels/ready-plan.ru/resources/views/email.blade.php ENDPATH**/ ?>